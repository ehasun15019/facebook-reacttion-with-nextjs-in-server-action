import my_pic from "./my_pic.jpg";

export const assets = {
  my_pic,
};
